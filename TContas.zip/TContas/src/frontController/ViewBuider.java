package frontController;

import java.util.ArrayList;

import contas.view.View;

public class ViewBuider {
	private ArrayList<View> views;
}
