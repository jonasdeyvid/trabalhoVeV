package contas.view;

public class View {
	
}
