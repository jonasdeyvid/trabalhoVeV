package principal;

import contas.view.ViewHome;

public class Principal {

	public static void main(String[] args) {
		ViewHome.mostrar();
	}

}
